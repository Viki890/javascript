// Importing necessary libraries
const prompt = require('prompt-sync')({ sigint: true });
const assert = require('assert');

// The board object used to save the current status of a gameplay
let board = {
    1: '1', 2: '2', 3: '3',
    4: '4', 5: '5', 6: '6',
    7: '7', 8: '8', 9: '9'
};

// Update the game board with the user input
function markBoard(position, mark) {
    board[position] = mark;
}

// Print the game board
function printBoard() {
    console.log(`${board[1]} | ${board[2]} | ${board[3]}`);
    console.log('---------');
    console.log(`${board[4]} | ${board[5]} | ${board[6]}`);
    console.log('---------');
    console.log(`${board[7]} | ${board[8]} | ${board[9]}`);
}

// Check for wrong input
function validateMove(position) {
    const numPosition = Number(position);
    return Number.isInteger(numPosition) && numPosition >= 1 && numPosition <= 9 && !isNaN(board[numPosition]);
}

// List out all the combinations of winning
let winCombinations = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9],
    [1, 4, 7],
    [2, 5, 8],
    [3, 6, 9],
    [1, 5, 9],
    [3, 5, 7]
];

// Check if the previous winner just won
function checkWin(player) {
    for (let combo of winCombinations) {
        if (combo.every(index => board[index] === player)) {
            return true;
        }
    }
    return false;
}

// Check if the game board is full
function checkFull() {
    return Object.values(board).every(cell => cell === 'X' || cell === 'O');
}

// Handle a player's turn
//checking for winning or tie
function playTurn(player) {
    let validMove = false;
    let position;

    while (!validMove) {
        position = prompt(`${player}'s turn, input a number between 1-9: `);
        
        // Check if the input is not a number
        if (isNaN(position)) {
            console.log('Invalid input. Strings are not allowed. Please enter a number between 1 - 9.');
            continue;
        }
    
        // Convert input to an integer
        position = parseInt(position);
    
        // Check if the input is not between 1 - 9
        if (position < 1 || position > 9) {
            console.log('Invalid move. Please enter a number between 1 - 9.');
            continue;
        }
    
        // Validate the move (this part depends on your game logic)
        validMove = validateMove(position);
    
        if (!validMove) {
            console.log('Invalid move. The position already taken or not allowed. Please try again.');
        }
    }
    
    markBoard(position, player);
    printBoard();
    
    if (checkWin(player)) {
        console.log(`!!!Player ${player} wins!!!`);
        return true;
    } else if (checkFull()) {
        console.log('The game is a tie!!');
        return true;
    }
    return false;
}

// Main program
function startGame() {
    console.log('Game started: \n\n' +
        ' 1 | 2 | 3 \n' +
        ' --------- \n' +
        ' 4 | 5 | 6 \n' +
        ' --------- \n' +
        ' 7 | 8 | 9 \n');

    let winnerIdentified = false;
    let currentTurnPlayer = 'X';

    while (!winnerIdentified) {
        winnerIdentified = playTurn(currentTurnPlayer);
        if (!winnerIdentified) {
            currentTurnPlayer = (currentTurnPlayer === 'X') ? 'O' : 'X';
        }
    }

    // Ask the user if they want to restart the game
    const restart = prompt('Do you want to play again? (yes/no): ').toLowerCase();
    if (restart === 'yes') {
        resetBoard();
        startGame(); // Restart the game
    } else {
        console.log('Thanks for playing!');
    }
}

function resetBoard() {
    board = {
        1: '1', 2: '2', 3: '3',
        4: '4', 5: '5', 6: '6',
        7: '7', 8: '8', 9: '9'
    };
}

// Start the game for the first time
startGame();

// Tests (These will run immediately after the game ends)
resetBoard();
let tsetBoard = {
    1: 'X', 2: 'O', 3: 'X',
    4: 'O', 5: 'X', 6: 'O',
    7: '7', 8: '8', 9: '9'
};

markBoard(1, 'X');
markBoard(2, 'O');
markBoard(3, 'X');
markBoard(4, 'O');
markBoard(5, 'X');
markBoard(6, 'O');

assert.deepStrictEqual(board, tsetBoard, "markBoard() didn't work as expected");

// Test validateMove()
assert.strictEqual(validateMove('1'), false, "validateMove() didn't work as expected with duplicated input : 1");
assert.strictEqual(validateMove('7'), true, "validateMove() didn't work as expected with available input : 7");

// Test checkWin()
resetBoard();
tsetBoard = {
    1: 'X', 2: '2', 3: '3',
    4: 'O', 5: 'X', 6: '6',
    7: 'O', 8: '8', 9: 'X'
};
markBoard(1, 'X');
markBoard(4, 'O');
markBoard(5, 'X');
markBoard(7, 'O');
markBoard(9, 'X');
assert.deepStrictEqual(board, tsetBoard, "markBoard() didn't work as expected with input (7, 'X')");
assert.strictEqual(checkWin('X'), true, "checkWin() didn't work as expected with input : 'X'");

board = {
    1: 'X', 2: '2', 3: '3',
    4: 'O', 5: 'X', 6: '6',
    7: 'O', 8: '8', 9: 'X'
};
assert.strictEqual(checkWin('X'), true, "checkWin() didn't work as expected with input : 'X'");
assert.strictEqual(checkWin('O'), false, "checkWin() didn't work as expected with input : 'O'");

board = {
    1: 'O', 2: '2', 3: '3',
    4: 'X', 5: 'O', 6: '6',
    7: 'X', 8: 'X', 9: 'O'
};
assert.strictEqual(checkWin('O'), true, "checkWin() didn't work as expected with input : 'O'");
assert.strictEqual(checkWin('X'), false, "checkWin() didn't work as expected with input : 'X'");

board = {
    1: 'X', 2: 'O', 3: 'O',
    4: 'X', 5: '5', 6: '6',
    7: 'X', 8: '8', 9: '9'
};
assert.strictEqual(checkWin('X'), true, "checkWin() didn't work as expected with input : 'X'");
assert.strictEqual(checkWin('O'), false, "checkWin() didn't work as expected with input : 'O'");

board = {
    1: 'X', 2: 'O', 3: 'X',
    4: 'X', 5: 'O', 6: '6',
    7: '7', 8: 'O', 9: '9'
};
assert.strictEqual(checkWin('O'), true, "checkWin() didn't work as expected with input : 'O'");
assert.strictEqual(checkWin('X'), false, "checkWin() didn't work as expected with input : 'X'");

board = {
    1: 'X', 2: 'X', 3: 'X',
    4: 'O', 5: 'O', 6: '6',
    7: '7', 8: '8', 9: '9'
};
assert.strictEqual(checkWin('X'), true, "checkWin() didn't work as expected with input : 'X'");
assert.strictEqual(checkWin('O'), false, "checkWin() didn't work as expected with input : 'O'");

board = {
    1: 'X', 2: 'X', 3: '3',
    4: 'O', 5: 'O', 6: 'O',
    7: 'X', 8: '8', 9: '9'
};
assert.strictEqual(checkWin('O'), true, "checkWin() didn't work as expected with input : 'O'");
assert.strictEqual(checkWin('X'), false, "checkWin() didn't work as expected with input : 'X'");

// Test checkFull()
resetBoard();
assert.strictEqual(checkFull(), false, "checkFull() didn't work as expected");
board = {
    1: 'O', 2: 'X', 3: 'O',
    4: 'O', 5: 'X', 6: 'X',
    7: 'X', 8: 'O', 9: 'X'
};
assert.strictEqual(checkFull(), true, "checkFull() didn't work as expected");

console.log("All tests passed! Congratulations!");